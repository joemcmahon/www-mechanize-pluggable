package MyTest::Plugin::Foo;


use strict;


1;


