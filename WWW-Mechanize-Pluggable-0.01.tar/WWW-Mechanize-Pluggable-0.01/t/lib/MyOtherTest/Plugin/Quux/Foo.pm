package MyOtherTest::Plugin::Quux::Foo;
use strict;
1;


