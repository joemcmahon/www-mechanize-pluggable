package MyOtherTest::Plugin::Foo;
use strict;
1;


