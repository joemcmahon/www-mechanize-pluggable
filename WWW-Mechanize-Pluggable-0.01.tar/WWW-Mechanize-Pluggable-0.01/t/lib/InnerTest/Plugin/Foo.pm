package InnerTest::Plugin::Foo;
use strict;

package InnerTest::Plugin::Bar;
use strict;

1;
