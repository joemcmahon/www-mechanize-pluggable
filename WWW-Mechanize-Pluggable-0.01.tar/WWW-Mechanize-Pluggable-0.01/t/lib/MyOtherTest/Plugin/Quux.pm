package MyOtherTest::Plugin::Quux;
use strict;
1;


